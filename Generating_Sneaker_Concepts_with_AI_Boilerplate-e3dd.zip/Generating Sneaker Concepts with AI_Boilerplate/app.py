"""
╔══════════════════════════════════════════════════════════════╗
║  LESSON 2 — Generating Sneaker Concepts with AI              ║
╚══════════════════════════════════════════════════════════════╝

GOAL: Connect Groq LLaMA 3 to generate a full sneaker concept
      JSON when the form is submitted. No captcha yet.

YOUR TASKS (app.py):
  1. Import Groq, create the client using GROQ_API_KEY from env
  2. Write DESIGN_PROMPT — a multi-line string with the JSON schema,
     using {style}, {primary_color}, {accent_color}, {material},
     {occasion}, {inspiration} placeholders
  3. Write generate_concept(prefs) — calls Groq, strips markdown
     fences, returns json.loads(raw)
  4. Add /generate POST route — calls get_prefs(), generate_concept(),
     returns jsonify({"success": True, "concept": ..., "prefs": ...})

YOUR TASKS (static/js/studio.js):
  5. Write collectPrefs() — returns object with all form values
  6. Write renderConcept(c) — populates result panel with concept data
  7. Wire Generate button — POST to /generate, call renderConcept on success

Run:  python app.py  →  http://localhost:5000/studio
"""

import os, json
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = "sneaker-studio-dev-key"

HCAPTCHA_SITE_KEY = os.environ.get("HCAPTCHA_SITE_KEY", "")


# ── TODO 1: Import Groq and set up the client ─────────────────


# ── TODO 2: Write DESIGN_PROMPT ───────────────────────────────


# ── TODO 3: Write generate_concept(prefs) ─────────────────────


def get_prefs(data):
    fields = [("style","casual"),("primary_color","white"),("accent_color","black"),
              ("material","leather"),("occasion","everyday"),("inspiration","")]
    return {k: data.get(k, d) for k, d in fields}


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/studio")
def studio():
    return render_template("studio.html", hcaptcha_site_key=HCAPTCHA_SITE_KEY)

@app.route("/history")
def history():
    return render_template("history.html", designs=[])


# ── TODO 4: Add /generate POST route ─────────────────────────


if __name__ == "__main__":
    app.run(debug=True, port=5000)
