# Boss Battle — Student Workspace

## What You're Building

You'll implement the boss fight system on top of the full game. Press B to summon the Demon Overlord. The boss has 3 phases, and when you defeat it your code generates a victory report with a rank.

## Setup

```bash
npm install
npm run dev
```

Opens at `http://localhost:4006`

## Optional: AI Dialogue

Add your Groq API key to `.env` for AI-powered NPC dialogue and area narration:

```
VITE_GROQ_API_KEY=gsk_...
```

Get a free key at [console.groq.com](https://console.groq.com)

## Before You Start

This lesson builds on Lessons 4 & 5. Previous functions are pre-filled in `src/student.js`. Paste your own solutions into the marked stubs if you want to use your own code.

## Your Task

Open `src/student.js` and implement the 4 new functions at the bottom:

| Task | Function | What it does |
|------|----------|--------------|
| 1 | `createBossFight()` | Create the boss fight object with entity, phase, phaseTimer |
| 2 | `checkPhaseTransition(bossFight)` | Detect phase changes at 66% and 33% HP |
| 3 | `attackBoss(player, bossFight)` | Deal damage to boss, award XP/gold on kill |
| 4 | `generateVictoryReport(player, bossFight, turns)` | Build the victory report with rank |

## How It Works

- Full open world with all enemies, quests, NPCs, and save/load
- Press **B** to spawn the Demon Overlord near you
- Attack the boss with SPACE/J — your `attackBoss()` is called
- Boss phases change at 66% and 33% HP — your `checkPhaseTransition()` handles this
- When the boss dies, your `generateVictoryReport()` shows the victory screen

## Controls

| Key | Action |
|-----|--------|
| WASD | Move |
| SPACE / J | Attack |
| Q | Dodge |
| F | Potion |
| E | Interact |
| B | Spawn Boss |
| TAB | Quest log |
| M | Toggle minimap |
| P | Pause |
| Ctrl+S | Save |
| R | Respawn |
| ESC | Release cursor |

## Reference

Constants in `src/engine.js` (read-only):

- `BOSS_HP = 320` — boss starting HP
- `BOSS_ATK = 28` — boss base attack
- `BOSS_PHASES` — phase config (label, color, attack interval)

## Boss Damage Formula

```js
newCombo = (player.comboCount + 1) % 4
isBig    = (newCombo === 3)
damage   = 14 + player.level * 4 + (isBig ? 30 : 0) + Math.floor(Math.random() * 10)
```

## Rank Thresholds

| Rank | Turns |
|------|-------|
| S | ≤ 5 |
| A | ≤ 10 |
| B | ≤ 20 |
| C | any |

## Tips

- `createBossFight` must return `{ entity: { name, x, y, hp, maxHp, alive }, phase, phaseTimer }`
- `checkPhaseTransition` returns `{ bossFight, transitioned, newPhase }` — always return all three
- `attackBoss` returns `{ player, bossFight, damage, killed, isBig }` — bossFight must contain the updated entity
- `generateVictoryReport` — `xpEarned` is always 300, `score` is always 5000
