# ===== LESSON 2 — Connect Gestures to AI Magic ================================
# Goal : Detect a gesture, call the Groq API for spell narration, call the
#        Hugging Face API for a spell scene image, and display both.
# Run  : streamlit run lesson2_boilerplate/app.py
# =============================================================================

# ---------- PROVIDED — do not edit below this line ---------------------------
import streamlit as st
from PIL import Image
import config
from gesture_utils import load_local_teachable_machine_model, predict_gesture_from_image
from ai_helpers import get_spell_name, build_image_prompt, generate_spell_text, generate_spell_image

st.set_page_config(page_title=config.APP_TITLE, page_icon=config.APP_ICON, layout="wide")

# Cleans raw model labels into friendly names
LABEL_MAP = {
    "Open Palm": "Palm", "Palm": "Palm", "Peace": "Peace",
    "Pointer": "Pointer", "Point": "Pointer",
    "Thumbs Up": "Thumbs Up", "Thumbsup": "Thumbs Up", "No Gesture": "No Gesture",
}

# Session state initialisation — stores prediction, spell text, spell image, etc.
for k in ["prediction", "spell_name", "spell_text", "spell_image", "input_source", "last_key"]:
    if k not in st.session_state:
        st.session_state[k] = None if k in ("prediction", "spell_image") else ""

# Dark fantasy CSS
def render_styles():
    st.markdown("""
        <style>
        .stApp    { background: radial-gradient(circle at top, #241339 0%, #100914 42%, #07070b 100%); color: #f5efff; }
        .hero     { padding: 22px; border-radius: 22px; border: 1px solid rgba(191,158,255,.20);
                    background: linear-gradient(135deg,rgba(44,24,70,.92),rgba(15,12,30,.96)); margin-bottom: 1rem; }
        .panel    { padding: 20px; border-radius: 22px; border: 1px solid rgba(191,158,255,.18);
                    background: rgba(255,255,255,.03); box-shadow: 0 0 32px rgba(118,80,255,.10); margin-bottom: 1rem; }
        .card     { padding: 14px; border-radius: 16px; background: rgba(94,67,170,.14);
                    border: 1px solid rgba(186,163,255,.18); margin-bottom: 10px; text-align: center; }
        .spell-box{ padding: 16px; border-radius: 16px; background: rgba(255,255,255,.03);
                    border: 1px solid rgba(255,255,255,.08); margin-bottom: 12px; }
        .pill     { display: inline-block; padding: 7px 14px; border-radius: 999px;
                    background: rgba(108,75,214,.18); border: 1px solid rgba(193,170,255,.18);
                    color: #efe7ff; margin-bottom: 12px; }
        </style>""", unsafe_allow_html=True)

# Cached model loader
@st.cache_resource(show_spinner=False)
def get_model():
    return load_local_teachable_machine_model(str(config.MODEL_PATH), str(config.LABELS_PATH))

# Label normalizer
def normalize(label: str) -> str:
    return LABEL_MAP.get(label.strip(), label.strip())
# ---------- END PROVIDED ------------------------------------------------------


# TODO 1 — AI generation function  (~10 lines)
# def generate_magic(label, spell, source):
#   with st.spinner("Casting AI magic from the detected gesture..."):
#       call generate_spell_text(label, spell, source) → store in st.session_state.spell_text
#       call generate_spell_image(build_image_prompt(spell, label, source)) → returns (img, err)
#       if img: store in st.session_state.spell_image
#       else:   set st.session_state.spell_image = None, show st.error(err)

# def generate_magic(label, spell, source):
#     ...


# TODO 2 — Prediction panel  (~22 lines)
# def prediction_panel(image, source):
#   st.session_state.input_source = source
#   st.image(image, caption="Gesture image", use_container_width=True)
#   st.markdown pill showing source
#   try:
#       model, labels = get_model()
#       pred = predict_gesture_from_image(model, labels, image)
#       normalize pred["label"] and each item["label"] in pred["top_predictions"]
#       st.session_state.prediction = pred
#       spell = get_spell_name(pred["label"]) → store in st.session_state.spell_name
#       st.success(f"Detected gesture: {pred['label']}")
#       st.progress(confidence)
#       two columns: left card = detected gesture, right card = spell name
#       build key = f"{source}:{label}:{confidence:.4f}"
#       if key != st.session_state.last_key:
#           show "✨ Generate AI Magic" button
#           on click: call generate_magic(label, spell, source), update last_key
#   except Exception as e: st.error(...)

# def prediction_panel(image, source):
#     ...


# TODO 3 — Output panel  (~14 lines)
# def show_output():
#   open panel div + st.subheader("🪄 AI Magic Output")
#   if spell_name: render spell-box div with spell name
#   if spell_text: render spell-box div with narration (replace \n with <br>)
#   if spell_image is not None: st.image(spell_image, caption="AI-generated spell scene", ...)
#   elif not spell_name: st.info("Detect a gesture and click Generate AI Magic to see the output.")
#   close panel div

# def show_output():
#     ...


# TODO 4 — Main layout  (~20 lines)
# def main():
#   render_styles()
#   st.markdown hero div with config.APP_ICON + config.APP_TITLE + description
#   left, right = st.columns([1, 1], gap="large")
#   with left:
#       open panel div + st.subheader("📷 Input")
#       tabs = st.tabs(["Webcam Capture", "Upload Image"])
#       tab[0]: cam = st.camera_input(...)
#               if cam: prediction_panel(Image.open(cam).convert("RGB"), "webcam")
#               else: st.info(...)
#       tab[1]: up = st.file_uploader(..., type=["png","jpg","jpeg"])
#               if up: prediction_panel(Image.open(up).convert("RGB"), "upload")
#               else: st.info(...)
#       close panel div
#   with right:
#       show_output()

# def main():
#     ...


# ---------- PROVIDED — do not edit -------------------------------------------
if __name__ == "__main__":
    main()
# ===== END LESSON 2 ===========================================================
